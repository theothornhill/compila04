package exampletree;

public abstract class Term extends Expr{
}
